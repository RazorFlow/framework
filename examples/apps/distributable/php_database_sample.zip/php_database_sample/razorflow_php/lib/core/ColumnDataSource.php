<?php

abstract class ColumnDataSource {

}

