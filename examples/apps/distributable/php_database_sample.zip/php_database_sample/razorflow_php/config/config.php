<?php

global $_rfConfig;

/**
 * Defaukt configuration settings.
 * staticRoot => Provide the url for serving the static assets.
 */

$_rfConfig = array(
  "staticRoot" => "{{webRoot}}",
  "rfDebug" => true,
  "rfDev" => true
);
