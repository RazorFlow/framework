<?php
// Welcome to RazorFlow Dashboard Framework!
//
// To learn more about how to use the PHP Bindings, visit http://razorflow.com/docs/


if(!defined("RF_FOLDER_ROOT")) {
    define("RF_FOLDER_ROOT", dirname (__FILE__));
    require "lib/bootstrap.php";
}
